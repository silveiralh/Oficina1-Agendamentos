/**
 * Spring MVC REST controllers.
 */
package com.utfpr.uniagenda.web.rest;
