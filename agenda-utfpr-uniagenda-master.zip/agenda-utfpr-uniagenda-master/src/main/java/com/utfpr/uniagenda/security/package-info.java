/**
 * Spring Security configuration.
 */
package com.utfpr.uniagenda.security;
