/**
 * Service layer beans.
 */
package com.utfpr.uniagenda.service;
