/**
 * JPA domain objects.
 */
package com.utfpr.uniagenda.domain;
