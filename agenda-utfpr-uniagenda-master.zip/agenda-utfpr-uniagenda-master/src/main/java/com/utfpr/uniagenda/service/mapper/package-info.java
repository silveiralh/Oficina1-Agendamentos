/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.utfpr.uniagenda.service.mapper;
