/**
 * Spring Data Elasticsearch repositories.
 */
package com.utfpr.uniagenda.repository.search;
