package com.utfpr.uniagenda.domain.enumeration;

/**
 * The StatusAgenda enumeration.
 */
public enum StatusAgenda {
    Livre, Ocupado, Atendido, Remarcado, Faltou
}
