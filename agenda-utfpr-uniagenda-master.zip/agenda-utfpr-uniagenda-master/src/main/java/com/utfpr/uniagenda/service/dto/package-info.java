/**
 * Data Transfer Objects.
 */
package com.utfpr.uniagenda.service.dto;
