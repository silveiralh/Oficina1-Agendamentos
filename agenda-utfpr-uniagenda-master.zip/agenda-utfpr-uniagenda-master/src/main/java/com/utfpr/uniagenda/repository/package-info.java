/**
 * Spring Data JPA repositories.
 */
package com.utfpr.uniagenda.repository;
