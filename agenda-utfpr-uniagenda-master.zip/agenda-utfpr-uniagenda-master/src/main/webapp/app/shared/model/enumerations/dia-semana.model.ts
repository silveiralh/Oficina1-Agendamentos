export const enum DiaSemana {
  Segunda_feira = 'Segunda_feira',
  Terca_feira = 'Terca_feira',
  Quarta_feira = 'Quarta_feira',
  Quinta_feira = 'Quinta_feira',
  Sexta_feira = 'Sexta_feira'
}
