export const enum StatusDia {
  Disponivel = 'Disponivel',
  Indisponivel = 'Indisponivel'
}
