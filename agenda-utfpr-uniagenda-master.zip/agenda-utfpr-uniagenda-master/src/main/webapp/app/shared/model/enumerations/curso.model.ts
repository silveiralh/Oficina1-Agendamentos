export const enum Curso {
  Engenharia_Eletrica = 'Engenharia_Eletrica',
  Engenharia_Computacao = 'Engenharia_Computacao',
  Engenharia_Eletronica = 'Engenharia_Eletronica',
  Engenharia_Mecanica = 'Engenharia_Mecanica',
  Engenharia_Controle_Automacao = 'Engenharia_Controle_Automacao',
  Engenharia_Software = 'Engenharia_Software',
  Analise_Desenvolvimento_Sistemas = 'Analise_Desenvolvimento_Sistemas'
}
