export const enum StatusAgenda {
  Livre = 'Livre',
  Ocupado = 'Ocupado',
  Atendido = 'Atendido',
  Remarcado = 'Remarcado',
  Faltou = 'Faltou'
}
