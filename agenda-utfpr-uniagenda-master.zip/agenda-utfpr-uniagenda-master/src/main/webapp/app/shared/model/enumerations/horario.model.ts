export const enum Horario {
  H8 = 'H8',
  H9 = 'H9',
  H10 = 'H10',
  H11 = 'H11',
  H12 = 'H12',
  H13 = 'H13',
  H14 = 'H14',
  H15 = 'H15',
  H16 = 'H16',
  H17 = 'H17',
  H18H = 'H18H',
  H19 = 'H19',
  H20 = 'H20',
  H21 = 'H21',
  H22 = 'H22'
}
