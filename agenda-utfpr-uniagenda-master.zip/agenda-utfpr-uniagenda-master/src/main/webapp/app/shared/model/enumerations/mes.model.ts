export const enum Mes {
  Janeiro = 'Janeiro',
  Fevereiro = 'Fevereiro',
  Marco = 'Marco',
  Abril = 'Abril',
  Maio = 'Maio',
  Junho = 'Junho',
  Julho = 'Julho',
  Agosto = 'Agosto',
  Setembro = 'Setembro',
  Outubro = 'Outubro',
  Novembro = 'Novembro',
  Dezembro = 'Dezembro'
}
