/**
 * Spring Data JPA repositories.
 */
package com.uniagenda.agenda.repository;
