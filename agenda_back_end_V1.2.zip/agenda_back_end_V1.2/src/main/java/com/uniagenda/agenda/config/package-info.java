/**
 * Spring Framework configuration files.
 */
package com.uniagenda.agenda.config;
