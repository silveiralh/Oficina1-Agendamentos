/**
 * Spring Security configuration.
 */
package com.uniagenda.agenda.security;
