/**
 * Data Transfer Objects.
 */
package com.uniagenda.agenda.service.dto;
