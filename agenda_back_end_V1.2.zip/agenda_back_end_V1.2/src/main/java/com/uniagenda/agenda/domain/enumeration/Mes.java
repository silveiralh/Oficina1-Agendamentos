package com.uniagenda.agenda.domain.enumeration;

/**
 * The Mes enumeration.
 */
public enum Mes {
    Janeiro, Fevereiro, Marco, Abril, Maio, Junho, Julho, Agosto, Setembro, Outubro, Novembro, Dezembro
}
