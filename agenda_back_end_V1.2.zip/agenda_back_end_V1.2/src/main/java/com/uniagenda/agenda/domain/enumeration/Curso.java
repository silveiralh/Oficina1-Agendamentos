package com.uniagenda.agenda.domain.enumeration;

/**
 * The Curso enumeration.
 */
public enum Curso {
    Engenharia_Eletrica, Engenharia_Computacao, Engenharia_Eletronica, Engenharia_Mecanica, Engenharia_Controle_Automacao, Engenharia_Software, Analise_Desenvolvimento_Sistemas
}
