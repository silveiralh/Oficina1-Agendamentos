package com.uniagenda.agenda.domain.enumeration;

/**
 * The StatusAgenda enumeration.
 */
public enum StatusAgenda {
    Livre, Agendado, Atendido, Remarcado, Faltou
}
