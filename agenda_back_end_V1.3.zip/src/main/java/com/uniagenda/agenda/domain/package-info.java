/**
 * JPA domain objects.
 */
package com.uniagenda.agenda.domain;
