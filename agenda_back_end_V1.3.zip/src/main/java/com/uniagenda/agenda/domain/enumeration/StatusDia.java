package com.uniagenda.agenda.domain.enumeration;

/**
 * The StatusDia enumeration.
 */
public enum StatusDia {
    Disponivel, Indisponivel
}
