/**
 * Data Access Objects used by WebSocket services.
 */
package com.uniagenda.agenda.web.websocket.dto;
