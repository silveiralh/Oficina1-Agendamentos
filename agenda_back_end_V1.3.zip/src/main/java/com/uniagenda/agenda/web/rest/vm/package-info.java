/**
 * View Models used by Spring MVC REST controllers.
 */
package com.uniagenda.agenda.web.rest.vm;
