/**
 * Service layer beans.
 */
package com.uniagenda.agenda.service;
